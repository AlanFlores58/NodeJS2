'''bash
mkdir -p ~/abs/jxcore 
cp PKGBUILD  ~/abs/jxcore
cd ~/abs/jxcore
makepkg -si
'''
